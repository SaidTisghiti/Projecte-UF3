# Entorns Virtuals

Un entorno virtual es un entorno Python en el que el intérprete Python, las bibliotecas y los scripts instalados en él están aislados de los instalados en otros entornos virtuales, y (por defecto) cualquier biblioteca instalada en un «sistema» Python, es decir, uno que esté instalado como parte de tu sistema operativo.

Aquí muestro el paso a paso de que hacer para poder tener un entorno virtual:

* Vamos a la terminal i ponemos el siguiente codigo para crear el entorno virtual, el cual podemos llamarlo como queramos, en mi caso lo llamare .projecte:
```
python -m venv .projecte
```
* Una vez creado el entorno virtual hay que iniciar-lo para poder descargar las librerias dentro de ellas, lo activaremos de la siguiente forma:
```
.projecte\Scripts\activate
```
* Una vez hecho lo anterior ya podemos descargar las librerias que necesitemos en el entorno virtual, en mi caso instalare flask i feedparser:
```
pip install flask
pip install feedparser
```
* Para poder salir del entorno virtual utilizaremos el siguiente comando:
```
deactivate
```
A continuación os dejo un enlace donde profundiza sobre el tema de los entornos vitruales:
[enllaç](https://www.sydle.com/es/blog/entorno-virtual-de-aprendizaje-6446f3ed46c98068e15a2c6f)

# Flask

Flask es un framework el cual su funcionalidad es hacer funcionar los codigos python y xml para desarollar una app(aplicación).

* Ahora muestro como podemos iniciar la aplicacion con flask, el cual es el siguiente comando:
```
flask run --debug
```
* Un cop hem inicialitzat amb flask, ja podem anar a la pagina web el qual seria el seguent:
[enllaç](http://127.0.0.1:5000/)

* Para poder parar la aplicacion utilizaremos las teclas *Ctrl+C*.

A continuación os dejo un enlace donde profundiza sobre el tema de el flask:
[enllaç](https://www.ionos.es/digitalguide/paginas-web/desarrollo-web/flask/)

# Jinja

Jinja es un motor de plantillas de Python que se utiliza para generar contenido dinámico en aplicaciones web. A continuación os pongo lo que aporta utilizar el Jinja:

* **Sintaxis sencilla:** Jinja utiliza una sintaxis sencilla y legible que se basa en delimitadores como doble llave *{{ }}* para expresiones, bloques *{% %}* para declaraciones de control y comentarios *{# #}* para comentarios.

* **Incorporación de datos dinámicos:** Permite la incorporación de datos dinámicos en las plantillas HTML o en otros archivos de plantillas. Puedes pasar variables, objetos y estructuras de datos desde Python al motor de plantillas para que sean renderizados en el contenido generado.

* **Estructuras de control:** Jinja admite estructuras de control como condicionales, bucles y bloques para la lógica del lado del servidor en las plantillas. Esto te permite personalizar el contenido según las condiciones especificadas.

* **Reutilización de código:** Facilita la reutilización de código gracias a la posibilidad de definir bloques de código que pueden ser heredados y extendidos en diferentes archivos de plantillas. Esto promueve la modularidad y la organización del código.

* **Extensibilidad:** Jinja es altamente extensible y permite la creación de extensiones personalizadas para ampliar su funcionalidad según las necesidades específicas de un proyecto.

* **Documentación completa:** Dispone de una documentación detallada y una comunidad activa, lo que facilita el aprendizaje y la resolución de problemas.

A continuación os dejo un enlace donde profundiza sobre el tema de el jinja:
[enllaç](https://revistacompleta.com/guia-completa-de-jinja-caracteristicas-esenciales/)

# RSS

RSS son las siglas de *Really Simple Syndication*, un formato que cumple con el estándar XML para compartir contenido en la web. Se utiliza para difundir información actualizada a usuarios que se han suscrito a una fuente de contenidos. El formato permite distribuir contenidos sin necesidad de un navegador, utilizando un software diseñado para leer estos contenidos RSS (agregador). Tambien es posible utilizar el navegador de internet para visualizar los contenidos RSS. A continuacion os pongo el funcionamiento:

* **Funcionamiento:** El RSS permite a los usuarios suscribirse a los contenidos de un sitio web y recibir actualizaciones automáticamente. Los sitios web que ofrecen RSS generan un archivo XML que contiene los títulos, resúmenes y enlaces de las últimas publicaciones o noticias.

Usando feedparser pillamos todo el xml y con rss seleccionamos lo que queremos o necesitamos i lo usamos en otro xml.

A continuación os dejo un enlace donde profundiza sobre el tema de el rss:
[enllaç](https://rockcontent.com/es/blog/feed-rss/)

# Feedparser

Feedparser es una biblioteca de python que su funcion es hacer funcionar el rss con python entre python y rss de forma sencilla.

* En el siguiente codigo, donde pone rss se utiliza el feedparser para pillar todo el xml, donde luego puedo usar rss para seleccionar y pillar lo que necesite de allí: 
```python
def get_rss_lavanguardia(seccio):
    # MODE REMOT: versió on descarrega l'XML de la web
    #xml = f"https://www.lavanguardia.com/rss/{seccio}.xml"
    
    # MODE LOCAL: versió que fa servir l'XML descarregat
    #xml = f"./rss/lavanguardia/{seccio}.xml"
    
    rss = feedparser.parse(xml)
    return rss
```

A continuación os dejo un enlace donde profundiza sobre el tema de el feedparser en ingles explicado a detalle:
[enllaç](https://mr-destructive.github.io/techstructive-blog/python-feedparser/)

# Bootstrap

Bootstrap es un framework CSS popular que se utiliza para desarrollar sitios web y aplicaciones web de manera rápida y sencilla. Proporciona una serie de estilos predefinidos, componentes y utilidades que facilitan la creación de diseños responsivos y atractivos. A continuacion mostrare los que hemos aprendido en clase:

### Containers

Tenemos diferentes contenedores donde pondre los codigos utilizados a clase, los clasificaré de mas grande a mas pequeño:

* .container-fluid
* .container-xxl
* .container-xl
* .container-lg
* .container-md
* .container-sm
* .container

### Colors

También tenemos diferentes colores, los cuales son los siguientes:

* .text-muted
* .text-primary
* .text-success
* .text-info
* .text-warning
* .text-danger
* .text-secondary
* .text-white
* .text-dark
* .text-body
* .text-light

Hay muchos mas, como puede ser el Grid, borders, Navbar, entre otros.

A continuación os dejo un enlace donde profundiza sobre el tema de el bootstrap:
[enllaç](https://rockcontent.com/es/blog/bootstrap/)

# Modo Remoto y Local

El modo remoto se refiere a pillar un xml a traves de un enlace web, en cambio el local es directamente pillar un xml ya descargado y utilizar-lo, a continuación muestro codigo de ejemplo donde se vee como en un caso y en otro lo pilla de diferentes lados:

* En este codigo, se utiliza el modo remoto, donde la variable xml seria el enlace de la pagina web donde necesitamos la informacion sin necesidad de tener el xml descargado:
```python
def get_rss_lavanguardia(seccio):
    # MODE REMOT: versió on descarrega l'XML de la web
    xml = f"https://www.lavanguardia.com/rss/{seccio}.xml"
    
    rss = feedparser.parse(xml)
    return rss
```
* En este otro codigo, tenemos que tener descargado el xml que necesitamos i a traves de rutas llegar al xml para poder agarrar la información que necesitamos:
```python
def get_rss_lavanguardia(seccio):
    # MODE LOCAL: versió que fa servir l'XML descarregat
    xml = f"./rss/lavanguardia/{seccio}.xml"
    
    rss = feedparser.parse(xml)
    return rss
```